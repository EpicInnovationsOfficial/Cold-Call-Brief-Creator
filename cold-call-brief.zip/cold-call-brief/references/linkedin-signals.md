# LinkedIn Signals

Use this list when reading a prospect's LinkedIn profile or a company's LinkedIn page. Each signal becomes a possible trigger for the opener. Only use a signal you can verify.

## Prospect profile

| Signal | What it may mean | How to use it |
|---|---|---|
| New in role (under 6 months) | New leaders review vendors and set priorities | "Congrats on the move to [role]. Many leaders in your first year are reviewing [category]..." |
| Promoted internally | Expanded scope, possibly new budget | Reference the scope change |
| Previous company in a related space | Experience with a competitor or a different approach | Ask what they learned at the earlier company |
| Recent post about a challenge | They are thinking about it now | Quote or paraphrase the post, and ask a question about it |
| Engagement with a vendor or industry post | Interest in a category | Reference the topic, not the engagement itself |
| Shared article or report | Priorities or concerns | Reference the theme |
| Mutual connection | Warm path | Ask for an introduction or name the connection |
| Shared school, group, or event | Rapport | Mention it briefly, only if relevant to the professional conversation |
| Certifications | Technical depth | Adjust question depth to match |
| Team size or scope described in profile | Scale of the problem | Frame context by company size |

Do not reference personal details such as family, health, or personal life. Keep the opener professional.

## Company page and job postings

| Signal | What it may mean |
|---|---|
| Job postings for security, identity, data, or platform engineering | Preparing for a new platform, or running a new one with staffing gaps |
| Postings for a role that is new to the company | New initiative or new function |
| Several postings for the same role | Hard to hire, or a major project |
| Postings that list a specific product or platform | The stack they use or are moving toward |
| Hiring freeze or layoffs | Cost pressure, or consolidation of tools |
| Growth in a department | Budget and priority for that function |
| Recent acquisitions | Integration complexity, duplicate systems, compliance merging |
| New funding round | Investment priorities for the next 12 months |
| New executive hire in a function | Vendor review opportunity |
| Expansion into a new market or region | New compliance and infrastructure needs |

## Competitor and industry signals

- A competitor of the prospect announced a platform change, a partnership, or a data breach. Use it as industry context, not as a criticism of the prospect.
- An industry regulation, certification, or deadline is approaching.
- An industry report shows a common challenge for companies of this size.

## Verification checklist

Before a trigger goes into an opener, check:
- Can I point to the source (URL, post, job listing, press release)?
- Is it recent enough to be relevant (generally within the last 6 to 12 months)?
- Could the salesperson say it truthfully without overstating it?
- Does it connect to a problem the salesperson's solution addresses?

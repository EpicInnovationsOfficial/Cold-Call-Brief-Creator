# Cold Call Framework

Source: the B2B tech cold calling method in the attached transcript, adapted for this skill. Treat it as a starting point and let `data/feedback-log.md` override it where the salesperson's results differ.

## Purpose of the call

Sell time, not the product. The call succeeds when the prospect agrees to a 20 to 30 minute discovery conversation. Do not try to explain the whole solution.

Target talk ratio: about 30% talking, 70% listening.

## The five stages

### 1. Permission opener (first 30 seconds)

Structure:
1. Name and company
2. Acknowledge the interruption
3. Ask permission to explain why you called
4. Give an easy out

Example:
> "Hi, this is [Name] from [Company]. I know I caught you out of the blue. Mind if I take a minute to tell you why I'm calling? And if it doesn't make sense for us to talk, just let me know. No sweat."

Why it works: asking for permission reduces resistance, and the easy out lowers pressure.

Avoid the generic opener: "We help clients create efficiencies and reduce cost through our cloud-based platform." It sounds like every other rep.

### 2. The reason (trigger and context)

Give a specific, verified reason to keep listening. A trigger is something you observed, researched, or verified: a job posting, a funding round, an acquisition, a leadership change, a post on LinkedIn, an industry event, a competitor's announcement.

Structure:
1. **Trigger:** what you noticed
2. **Context:** what that usually means for companies in this situation (the likely reasons, or the challenges that come with them)
3. **Check:** ask whether one of those is on their mind, or whether you are off base

Example (job posting trigger):
> "I noticed you posted a role for an identity management engineer. When companies post that role, it's usually because they're preparing for a new identity governance platform, they've just finished one and need to enhance it, or they need someone to run it and that's hard to hire for. Are any of those on your mind, or am I totally off base?"

Why it works: it shows research, gives them three specific options, and makes "off base" an easy answer.

#### The three-bucket question

Use this when a trigger suggests a likely cause. Offer three specific possibilities, labeled A, B, and C, drawn from the research, and ask which one fits. Then ask one follow-up: "How long have you been planning for that?" and "What's driving that decision?"

Example buckets for a job posting for a security engineer:
- **A:** You're implementing a new platform and need staff to support it.
- **B:** You've just finished an implementation and need to enhance it.
- **C:** You need to run the platform, and finding the right people is hard.

Choose buckets that match the trigger. Never present a bucket as fact. Each one is a hypothesis for the prospect to confirm or reject.

### 3. Diagnostic questions (conversation starter)

Move from the reason into short diagnostic questions. The aim is to find the surface pain and then the business problem behind it.

Useful questions:
- How are you handling that today?
- How long has that been a challenge?
- What have you tried so far?
- What other options are you considering?
- What happens if you don't solve it?
- Is there a deadline tied to it?
- What's driving that decision?

Pain indicators to listen for:
- Manual processes
- System limitations or aging platforms
- Time-consuming workarounds
- Compliance or risk concerns
- Integration problems
- Staffing or managed service costs ("care and feeding")
- Acquisitions adding complexity

Surface pain is not enough to close. On a cold call, you only need enough to justify a discovery meeting, where the root cause gets explored.

If the prospect goes deep and answers several questions at once, stop following the script and listen. Note the business challenge in their words.

### 4. The meeting request

Ask for 20 to 30 minutes. Fifteen is usually too short. An hour is too much for a stranger.

Framing:
> "Based on what you shared, we've seen this come up with other companies in your industry, and there are a few things that usually slow down these projects. I'd like to share how we're helping others with that, or at a minimum share what your industry peers are doing. Would it make sense to grab 20 to 30 minutes?"

Then:
1. Ask them to open their calendar while you are on the phone.
2. Offer two or three specific options within the next three to five days. Example: "How does Thursday at 2:00 look?"
3. Do not say you are "wide open." It makes you sound junior, and buyers want experienced reps.
4. Send the invite and get it accepted before you hang up.

Alternative close (for A/B testing against the framework above):
> "Based on what you shared, it might make sense to have a 20 to 30 minute conversation to unpack this further. Do you have time Thursday or Friday, at either 2:00 or 4:00?"

Test one variation at a time over at least 50 attempts each.

### 5. Clear next step

End every call with a specific next step:
- Meeting booked, invite accepted: confirm the date and attendees.
- Not now: find out the right time, and set the next touch.
- Already has a vendor: ask for permission to check in on a schedule, and agree on what you will send.
- Send me information: ask what challenges the information should address, then take their email and permission to keep sending relevant content.

Do not end with vague follow-up language.

## Objection responses

General principle: acknowledge, empathize, ask a question, then accept the answer. Do not argue, and do not explain why you are better.

### "I'm not interested."
Wrong: "I understand, but let me tell you why you should be."
Right: "Hey, I completely understand, and I'm sure you get calls like this all the time. The only reason I'm calling is that I saw [trigger]. Is that something your team handles, or have you already solved it?"
Then listen. If they say they have solved it, accept it: "Totally understand. Mind if I try you another time?"

### "We already have a vendor for that."
Wrong: "Oh, we're different because..." (this insults their decision)
Right: "That's great. How long have you been working with them?" Then: "If you could rewind six months, is there anything you'd have set up differently?"
If they are locked into a contract: "Totally get it. Would it be all right if I checked in every quarter, and shared what we're seeing in the industry?" Then follow through with useful content.

### "Send me some information."
Wrong: "Sure, what's your email?"
Right: "I'm happy to send something relevant. Could you take a minute to tell me your current challenges, so I send something you'll actually want to read?" Then get their email and ask, "Would it be valuable if I kept sending you material on this topic?"

### "I'm busy right now."
Wrong: "It'll just take a minute." (They will hear pressure.)
Right: "Totally understand. I called you out of the blue and you weren't expecting it. What would be a better time to talk about [trigger]?" Ask them to open the calendar and book it on the spot, or agree on a callback time.

### "Can you just email me?" / "Not a good time."
Treat these the same as the objections above. Get a specific time or a specific request.

### Objections to expect from technical and senior buyers
- "We built this in-house." Ask what the in-house solution does well and what it costs to maintain.
- "We're in a budget freeze." Ask what would make the investment worth revisiting next cycle.
- "I've been burned by vendors before." Acknowledge it. Ask what went wrong, and what they would need to see differently.
- "Send me your technical documentation." Ask which architecture or integration question they want answered first, and book a call to cover it.

## Mindset

- **Detach from the outcome.** Not every prospect is a fit, and not every "no" is final. Use each objection as information.
- **Keep going.** One day of calls is not enough. Cold calling works through consistent volume over weeks.
- **Practice the framework.** Practice openers out loud. The goal is a natural delivery, not a memorized script.
- **Track results.** Record each call's opener, objection, and outcome in `data/feedback-log.md`.

## Mistakes to avoid

1. Talking too much. Ask, then listen. Take notes.
2. Leading with features. Lead with their problem.
3. Fearing objections. Engage with them, because engagement is better than a hang-up.
4. Giving up too early.
5. Ending without a clear next step.
6. Using the same script for every prospect.

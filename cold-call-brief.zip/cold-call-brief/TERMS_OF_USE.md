TERMS OF USE

Terms of Use
Cold Call Brief is made available by Epic Innovations, Inc. free of charge, under the terms below. This is a plain-language summary of what you can and can't do with it, and what you're agreeing to by using it. It isn't a substitute for your own legal advice if you need certainty about a specific use case.

1. What you're allowed to do
You may, at no cost:

* Download, install, and run this skill in your own Claude account.
* Use it to prepare for your own B2B sales calls.
* Modify your own local copy to fit your needs (different brief sections, different question sets, tweaks to the persona, tone, or output format).
* Share a link back to this repository so others can get their own copy.

2. What you're not allowed to do
Without prior written permission from Epic Innovations, Inc., you may not:

* Republish, redistribute, or rehost the files in this repository (as-is or modified) anywhere else, including other repositories, package registries, or paid/free product listings.
* Remove or alter the attribution to Epic Innovations, Inc.
* Present this skill, or a modified version of it, as your own original work.
* Sell it, sublicense it, or bundle it into a commercial product or service offered to others.
* Use the Epic Innovations, Inc. name or branding to imply an endorsement, partnership, or affiliation that doesn't exist.

If you want to do any of the above, ask first: [www.epicinnovations.com](https://www.epicinnovations.com).

3. No warranty
This skill is provided "as is," with no warranty of any kind, express or implied, including, without limitation, any warranty that it will be accurate, complete, uninterrupted, error-free, or fit for a particular purpose.
In plain terms: it's a tool built and shared in good faith, but nobody is certifying that the research, triggers, questions, objection responses, or suggested language it produces will be correct for every prospect, industry, or market, or that using it will improve your results.

4. Use at your own risk
You're responsible for how you use this skill and for anything you do based on its output, including:

* Verifying every fact, trigger, and source in a brief before relying on it or saying it on a call. Research tools can misread, miss, or date-stamp information incorrectly.
* Not making claims about your product, customers, results, or pricing that you cannot support.
* Complying with the laws and rules that apply to your calls, including rules on unsolicited calls, call recording and consent, data protection, and do-not-call lists in every jurisdiction where you or your prospect are located. This skill does not provide legal or compliance advice.
* Respecting the privacy of the people you research. Use only professional information, and do not use the skill to profile private individuals.
* Any consequences of using this skill's briefs, openers, or feedback records in your own sales communications or coaching decisions.

5. Limitation of liability
To the fullest extent permitted by law, Epic Innovations, Inc. (including its founders, employees, subcontractors, etc.) are not liable for any direct, indirect, incidental, or consequential damages arising from your use of, or inability to use, this skill, including but not limited to a lost sale, a missed meeting, a miscommunication with a prospect, a regulatory penalty, a coaching decision made based on a brief, or any cost incurred running it.

6. Changes
These terms, and the skill itself, may be updated at any time. The version in this repository at the time you download it is the version that applies to that download.

7. Questions
[www.epicinnovations.com](https://www.epicinnovations.com)

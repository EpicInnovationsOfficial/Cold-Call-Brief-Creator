# Seller Profile

Fill this in once. The cold-call-brief skill reads it on every run. Update it when offerings or proof points change.

## Salesperson
- Name:
- Title:
- Company:
- Preferred call tone: (e.g., calm and consultative, direct, warm)

## What I sell
- One-sentence description:
- Main business outcome it delivers:
- Product or solution category:
- Typical deployment or implementation time:

## Who I sell to
- Target company types (industry, size, geography):
- Target buyer titles (primary and secondary):
- Technical depth expected on calls (low / medium / high):

## Proof points
- Customer type and result (anonymize if needed):
- Customer type and result:
- Named logos I can reference (yes / no, and which):

## Competitors and alternatives
- Usual competitors:
- Common alternatives (in-house, spreadsheets, existing vendor):
- How prospects usually describe the problem before they find us:

## Constraints
- Things I should never say or claim:
- Pricing questions: (defer to discovery / OK to mention range)

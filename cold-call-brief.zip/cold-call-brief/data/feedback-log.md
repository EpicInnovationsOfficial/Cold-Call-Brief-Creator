# Feedback Log

The salesperson records call results here, or tells the skill and the skill records them. The skill reads this log before writing openers and objection responses.

## How to use
- Log one entry per call, or one entry per batch of calls with the same opener.
- Keep the opener label consistent (A, B, C) so results can be compared.
- Do not draw conclusions from fewer than about 20 attempts per variation.

## Variation tracker

| Opener variation | Attempts | Meetings booked | Booking rate | Notes |
|---|---|---|---|---|
| A: Permission and trigger (framework) | 0 | 0 | | |
| B: Shorter direct version | 0 | 0 | | |
| Other | 0 | 0 | | |

## Call log

<!-- Format for each entry:

### [Date] | [Company] | [Prospect title] | [Brief used]
- Opener used: [A / B / C / other]
- Trigger used: [...]
- Prospect response to opener: [...]
- Objection heard: [...]
- Response used: [...]
- Outcome: [meeting booked / callback set / not now / no fit / no answer]
- What resonated: [...]
- What fell flat: [...]
- Suggested change: [...]
-->

## Patterns noticed
<!-- Add dated observations once there are enough attempts to support them. -->

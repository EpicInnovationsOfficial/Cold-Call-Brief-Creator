# Swipe File

Accumulated research for reuse across briefs. The skill appends to this file after every brief. Each entry has a source and a date. Re-verify anything older than about six months before using it in an opener.

---

## Industries

<!-- Format:
### [Industry]
- [Date] [Fact or trend] (Source: [link])
- [Date] Common challenge: [challenge] (Source: [link])
- [Date] Regulatory or market pressure: [item] (Source: [link])
-->

---

## Personas (job titles)

<!-- Format:
### [Job title] in [industry or company size]
- Current priorities: [...]
- Common challenges: [...]
- Questions this persona tends to ask: [...]
- Objections heard: [...] (see feedback-log for outcomes)
-->

---

## Companies researched

<!-- Format:
### [Company] (researched [date])
- Prospect: [name, title]
- Triggers: [trigger] (Source: [link])
- Status: [not contacted / contacted / meeting booked / not now / no fit]
- Notes: [professional notes only]
-->

---

## Win stories

<!-- Format:
### [Anonymized customer type]
- Situation: [...]
- Result: [measurable outcome, if approved to share]
- Usable in: [industry / persona]
- Source: [seller provided, date]
-->

---

## Field notes from calls

<!-- Format:
- [Date] [Industry / persona]: [What the prospect said that was useful, in their words]
-->

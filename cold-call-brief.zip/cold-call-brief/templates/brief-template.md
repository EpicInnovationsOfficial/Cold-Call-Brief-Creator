# Cold Call Brief Template

Build the brief as a Word document with this structure. Keep it to about four to six pages.

---

**Title:** Cold Call Brief: [Prospect Name], [Title] at [Company]
**Prepared for:** [Salesperson name], [Salesperson company]
**Prepared on:** [Date]
**Sources researched:** [Count] | **Last verified:** [Date]

---

## 1. Call Snapshot

| | |
|---|---|
| **Prospect** | [Name, title] |
| **Company** | [Company, industry, size if known] |
| **Tenure in role** | [Time, and whether it is a new role] |
| **Best trigger** | [One sentence: the strongest verified reason to call] |
| **Call objective** | Book a 20 to 30 minute discovery meeting |
| **Warm path** | [Mutual connection, referral, or "none"] |

## 2. Why Now: Research Summary

Company triggers (verified, with sources):
- [Trigger] (Source: [link], [date])
- [Trigger] (Source: [link], [date])

Prospect context:
- [Relevant fact from the profile or recent activity]

Industry context:
- [Trend, competitor move, or regulatory pressure, with source]

Unverified items (use with caution, or do not mention on the call):
- [Item]

## 3. Conversation Openers

**Opener A (recommended): Permission and trigger**
> [Full script, in the permission-based structure]

*Delivery note:* Calm, downward inflection. Pause after the trigger and let them respond.

**Opener B (test variation): Shorter direct version**
> [Full script]

*Delivery note:* [Brief note]

**Opener C (alternative trigger)**
> [Full script using a different trigger]

*Delivery note:* [Brief note]

**Based on prior results:** [Note from feedback-log, or "No history yet. Track which opener you use."]

## 4. Suggested Questions

Ask in this order. Listen fully before moving to the next question.

| # | Question | Why ask it | Listen for | If you hear this, follow up with |
|---|---|---|---|---|
| 1 | [Question] | [Purpose] | [Signal] | [Follow-up] |
| 2 | [Question] | [Purpose] | [Signal] | [Follow-up] |
| 3 | [Question] | [Purpose] | [Signal] | [Follow-up] |
| 4 | [Question] | [Purpose] | [Signal] | [Follow-up] |
| 5 | [Question] | [Purpose] | [Signal] | [Follow-up] |
| 6 | [Question] | [Purpose] | [Signal] | [Follow-up] |

**Pain indicators to note:** manual processes, system limits, time-consuming workarounds, compliance or risk exposure, integration problems.

## 5. Objection Handling

| Likely objection | Acknowledge and respond | Next step |
|---|---|---|
| "I'm not interested." | "I completely understand. The only reason I called is [trigger]. Is that something your team handles, or have you solved it?" | If solved: "Mind if I check back another time?" |
| "We already have a vendor." | "That's great. How long have you been working with them? If you could rewind six months, what would you set up differently?" | If locked in: agree on a quarterly check-in and content |
| "Send me some information." | "I'd be glad to. Could you tell me your top challenges so I send something useful?" | Get email and permission to keep sending |
| "I'm busy right now." | "Totally understand. I caught you out of the blue. When would be a better time to talk about [trigger]?" | Book a specific time |
| [Prospect-specific objection] | [Response] | [Next step] |
| [Prospect-specific objection] | [Response] | [Next step] |

## 6. Closing Checklist

**Before you end the call, confirm:**

- [ ] Meeting date, time, and time zone agreed
- [ ] Calendar invite sent and accepted while on the call
- [ ] All attendees named, and their roles
- [ ] Their current solution or vendor, and contract timing if known
- [ ] The main pain, in their words
- [ ] The business impact they mentioned (cost, risk, timeline, growth)
- [ ] Any deadline tied to the problem
- [ ] Permission to send follow-up material
- [ ] Preferred contact method and best phone or email

**If no meeting is booked, confirm:**

- [ ] The reason (not now, already solved, vendor locked in, no fit)
- [ ] The right time to follow up, and the date you will call back
- [ ] Permission to add value through content, and what kind
- [ ] A clear, specific next step

**After the call:**

- [ ] Log the opener used, objection heard, response, and outcome in the feedback log
- [ ] Note new facts for the swipe file
- [ ] Send the invite or follow-up email within the hour
- [ ] Send any promised content

---

*Sources:* [Numbered list of URLs and documents used]
